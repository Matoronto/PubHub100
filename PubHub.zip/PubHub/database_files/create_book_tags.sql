create table book_tags (
	isbn_13 varchar (13), NOT NULL
	tag_name varchar (20), NOT NULL
	foreign key (isbn_13) References books(isbn_13)
);

insert into books values (
  '3333333333333',          	-- id
  'Soccer',    -- title
  'Mathewos Mekuria', 			-- author
  current_date,    				-- publishDate
  130.00,   					-- price
  null							-- blob
);

insert into book_tags values(
  '3333333333333', 'Sports');
  
select * from book_tags

update book_tags
set tag_name = 'Travel'  
where isbn_13 = '2222222222222';

update book_tags
set tag_name = 'Sports'
where isbn_13 = '3333333333333';

