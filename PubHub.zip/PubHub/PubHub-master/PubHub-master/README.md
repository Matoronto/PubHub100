# PubHub
A Web Application to publish books online 
For this project I have extended the Book Publishing System of PubHub,
a self-publishing platform that allows anyone to write, publish, and sell their
own books. Application has functionality for uploading and downloading
files from the PubHub database and tagging system. 
Users are able to add descriptive tags to books, and then search the application
for books based on those tags. Full database to support data and also displays it for a user
and allows them to manipulate it through an online interface.

Coded in: Java, Javascript, JQuery, MySQL, HTML & CSS.

