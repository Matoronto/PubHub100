This folder contains .jsp files
