package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class CounterServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		Integer counter = 1;
		
		if (session.getAttribute("visits") == null)
			session.setAttribute("visits", counter);
		else {
			counter = (Integer) session.getAttribute("visits");
			counter++;
			session.setAttribute("visits", counter);
		}
		
		PrintWriter out = response.getWriter();
		out.println("Visits: " + counter);
	}

}
