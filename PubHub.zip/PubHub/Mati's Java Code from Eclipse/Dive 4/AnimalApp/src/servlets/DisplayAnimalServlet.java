package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Animal;


public class DisplayAnimalServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Animal anim = (Animal) request.getAttribute("myAnimal");
		
		String outputHTML = 
				"<!DOCTYPE html>" +
				"<html>" +
				"<head>" +
				"<meta charset=\"ISO-8859-1\">" +
				"<title>Your Animal</title>" +
				"</head>" +
				"<body>"+
				anim.getName() +", the <em>" + anim.getGenus() + " " + anim.getSpecies() + "</em>" +
				"</body>" +
				"</html>";
		
		PrintWriter out = response.getWriter();
		
		out.println(outputHTML);
	}

}
