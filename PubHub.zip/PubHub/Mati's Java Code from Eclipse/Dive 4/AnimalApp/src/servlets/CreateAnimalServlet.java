package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Animal;

public class CreateAnimalServlet extends HttpServlet {

	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Animal anim = new Animal();
		
		anim.setName(request.getParameter("animalName"));
		anim.setGenus(request.getParameter("animalGenus"));
		anim.setSpecies(request.getParameter("animalSpecies"));
		
		request.setAttribute("myAnimal", anim);
		
		getServletContext().getRequestDispatcher("/showAnimal").forward(request, response);
	}

	
}
